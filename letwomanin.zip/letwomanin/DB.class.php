<?php

include "config.php";
class DbWorking
{
    private $host;
    private $dbname;
    private $dbuser;
    private $dbpass;

    function __construct()
    {            // enter ur database info's
        $this->host = DB_HOST;
        $this->dbname = DB_NAME;
        $this->dbuser = DB_USER;
        $this->dbpass = DB_PASS;
    }

    public function query($query, $var = array(), $err = true)
    {            // secure variables and submit the query . enter variables in array .
        if (is_array($var)) {                                    // Variables must enter in array !
            try {
                $PDO = new PDO("mysql:host={$this->host};dbname={$this->dbname};charset=utf8", $this->dbuser, $this->dbpass);
                if (sizeof($var) > 0) {
                    $res = array();
                    foreach ($var as $item) {
                        $search = array(
                            '@<script[^>]*?>.*?</script>@si',   // Strip out javascript
                            '@<[\/\!]*?[^<>]*?>@si',            // Strip out HTML tags
                            '@<style[^>]*?>.*?</style>@siU',    // Strip style tags properly
                            '@<![\s\S]*?--[ \t\n\r]*>@'         // Strip multi-line comments
                        );

                        $item = preg_replace($search, '', $item);

                        if (get_magic_quotes_gpc()) {
                            $item = stripslashes($item);
                        }

                        $item = trim(htmlspecialchars($item));
                        $res[] = $item;
                    }
                } else {
                    $res = array();
                }
                $sql = $PDO->prepare($query);
                if ($sql->execute($res)) {
                    return $sql;
                } else {
                    if ($err) {
                        echo "<br>";
                        print_r($sql->errorInfo());
                        echo "<br>Error occured !<br>";
                        print_r($sql->errorCode());
                    }
                }
            } catch (PDOException $e) {
                print_r($e);
            }
        } else {
            die("Error ! : Variables must enter in array !");
        }

    }
}