
<?php
include_once "functions.php";
ini_set('display_errors', 1);
if(isset($_POST["username"], $_POST["gender"], $_POST["mail"])){
    if (!empty($_POST["username"]) && !empty($_POST["mail"])){

        switch (do_petetion()){
            case ("E1");
                $result = "لطفا تایید کنید که روبات نیستید .";
                break;
            case ("A1");
                $result = "شما نمیتوانید بیش از یکبار امضا کنید !";
                break;
            case ("A0");
                $result = "امضای قبلی شما تایید نشده است ! لطفا از طریق ایمیلتان امضای خود را تایید کنید در غیر اینصورت امضای شما محاسبه نخواهد شد !";
                break;
            case ("E0");
                $result = "متاسفانه مشکلی در ثبت امضا پیش آمد ! لطفا دوباره تلاش کنید ! ";
                break;
            case ("S");
                $result = "امضای شما با موفقیت ثبت شد ! لطفا امضای خود را از طریق ایمیلی که وارد نموده اید تایید کنید.";
                break;
        }
    }else{
        $result = "لطفا اطلاعات را به صورت کامل وارد کنید !";
    }

}else{
    $result = "";
}

$signcount = $sql->query("SELECT COUNT(`email_activated`) AS ecount FROM `petetion` WHERE `email_activated`=? ", array(1))->fetch(2)["ecount"];

if (isset($_GET["e"], $_GET["t"])){
    switch (verifyEmail($_GET["e"], $_GET["t"])){
        case ("S");
            echo "<script>alert('امضای شما با موفقیت ثبت و تایید شد !')</script><meta http-equiv='refresh' content='0;url=/'>";
            break;
        case ("E1");
            echo "<script>alert('کد تایید شما منقضی شده است یا ایمیل شما معتبر نیست !')</script><meta http-equiv='refresh' content='0;url=/'>";
            break;
    }
}


$tweets = @json_decode(@file_get_contents("tweets.html")) // add your file . change line


?>


<html>

<head>
    <title>کمپین حمایت از ورود زنان به استادیوم</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="twitter:card" content="summary">
    <meta property="og:type" content="website"/>
    <meta name="description" content="{{ description }}">
    <meta property="og:description" content="{{ description }}">
    <meta name="twitter:description" content="{{ description }}">
    <meta name="author" content="@LetWomanIn">
    <meta name="twitter:creator" content="@LetWomanIn">
    <!--<link rel="shortcut icon" href="">
    <meta property="og:image" content="">-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="static/css/fontiran.css" rel="stylesheet">
    <link href="static/css/style.css" rel="stylesheet">
    <link href="static/css/font-awsome.css" rel="stylesheet">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>

<body>

<nav>
    <div class="container">
        <div class="nav-wrapper">
            <a href="/" class="brand-logo center">کمپین حمایت از حقوق۴۹درصدی!</a>
        </div>
    </div>
</nav>
<main>
    <div class="container">

        <div class="row">
            <div class="col s12">
                <div class="card">
                    <div class="card-content">
                        <div class="title-container"><span class="card-title">در مورد کمپین</span></div>
                        <div class="row">
                            <div class="col s12 m4 right">
                                <img class="responsive-img" src="static/img/logo2.png"/>
                            </div>
                            <div class="col s12 m8 left">
                                <p>ورود زنان به ورزشگاه ها هیچ منع قانونی و شرعی ندارد و جلوگیری از ورود آنان به این مکان ها نادیده گرفتن حق حدود 50٪ از جمعیت ایران است ! چرا که لذت بردن از ورزش و شادی برای برد حق همه ماست و منع ورود زنان ظلمی آشکار نسبت به حقوق انسانی آن هاست. </p>
                                </br><p>این کمپین تنها برای « حضور زنان در ورزشگاه ها » نیست ! باطن این کمپین حمایت از حقوق زنان است . چه درورزشگاه ها ،‌ چه در خیابان و چه در خانه و محل کار . این حق تنها حقی 49 درصدی نیست ! بلکه حقی 100 درصدی است چرا که حق هر زنی که ضایع می شود مانند آن است که حق همه ی ما ضایع شده است .</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col m12 l6">
                <div class="card">
                    <div class="card-content">
                        <div class="title-container"><span class="card-title">آخرین توییت‌ها</span></div>
                        <div class="row">
                            <div class="col s12">
                                <ul class="collection">
                                    <li class="collection-item avatar">

                                        <?php


                                        // code for printing tweets here


                                        ?>
                                        <img src="http://materializecss.com/images/yuna.jpg" alt="" class="circle">
                                        <span class="title">خانج میگه:</span>
                                        <p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سط
                                        </p>
                                        <p>
                                            <a class="waves-effect waves-light btn">توییت <i class="fa fa-twitter"></i></a>
                                        </p>
                                    </li>

                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col m12 l6">
                <div class="card">
                    <div class="card-content">
                        <div class="title-container"><span class="card-title">امضا</span></div>
                        <div class="row">
                            <div class="col s12">
                                <p>
                                    همانطور که بالا خواندید، این کمپین برای حمایت از <a href="https://twitter.com/hashtag/%D8%AD%D9%82%D9%88%D9%82%D9%A4%D9%A9%D8%AF%D8%B1%D8%B5%D8%AF%D9%89?src=hash">#حقوق۴۹درصدی</a> راه‌افتاده‌است. برای محقق‌کردن هدف مشترکمان، شما می‌توانید با ثبت ایمیل و اسمتان و سپس تایید ایمیلتان، این دادخواست را امضا کنید !برای تایید امضای شما و محاسبه آن باید ابتدا با لینک تاییدی که به شما فرستاده می‌شود (ممکن است در پوشه اسپم یا اینباکس باشد)، ایمیلتان را تایید کنید، سپس امضایتان تایید می‌شود! در نظر داشته باشید که گرفتن ایمیل تنها و تنها جهت رسمیت بخشیدن به امضای شما و در صورت نیاز ارسال دادخواست جدید هست و هیچ‌گونه استفاده دیگری (اعم از ارسال اسپم و یا فروش دیتابیس ایمیل) نخواهد داشت!
                                </p>
                                <br><br><br>

                                    <i class="fa fa-thumbs-up" aria-hidden="true"></i>
                                    امضاهای جمع شده:
                                    </br></br>
                                <div class="row">
                                    <div class="col s1"><?php echo $signcount; ?></div>
                                    <div class="col s10"><div class="progress"><div class="determinate" style="width: 90%"></div></div></div>
                                    <div class="col s1">۰</div>
                                </div>

                                </p>
                                <form class="col s12" method="post" >
                                    <div class="row">
                                        <div class="input-field col s6">
                                            <input placeholder="نام شما" id="username" type="text" name="username" required="required">
                                            <label for="username">نام شما</label>
                                        </div>
                                        <div class="input-field col s6">
                                            <select name="gender" required="required">
                                                <option value="0">مرد</option>
                                                <option value="1">زن</option>
                                                <option value="2">تراجنسی</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="input-field col s12">
                                            <input placeholder="ایمیل شما" id="useremail" type="email" name="mail" class="validate" required="required">
                                            <label for="username" data-error="نادرست" data-success="درست">ایمیل شما</label>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="g-recaptcha" data-sitekey="6Lcp7iUUAAAAAAI0mJQTPo02Xmzb7FghiDro-hRu"></div>
                                    </div>
                                    </br>
                                    <button class="btn waves-effect waves-light" type="submit" value="submit">امضا دادخواست <i class="material-icons left">done</i></button>
                                </form>
                                <br>
                                <?php echo "<p style=\"color: green;\"><b>{$result}</b></p>"; ?>
                                <br>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col s12">
                <div class="card">
                    <div class="card-content">
                        <div class="title-container"><span class="card-title">حمایت از کمپین</span></div>
                        <div class="row">
                            <div class="col s12 m4 right">
                                <img class="responsive-img" src="static/img/wallet.png"/>
                            </div>
                            <div class="col s12 m8 left">
                                <p>
                                    برخلاف این‌که ممکن هست شما حدس بزنین ما حمایت‌های مالی از سمت سازمان‌های مختلف دریافت می‌کنیم، ما کمپینی هستیم که کاملا بی‌طرفانه و با هدف بهبود شرایط برای حضور و احقاق حقوق زنان شروع به‌کار کردیم! از آنجایی که برپایی و نگاهداری چنین صفحه‌ای خرج‌های متعددی مانند سرور و دامنه دارد، نیاز به حمایت مالی شما داریم. همچنین در جهت ناشناسی افراد پشت این کمپین می‌کوشیم و از همین جهت در حال حاضر فقط ارز بیتکوین را به عنوان حمایت مالی از کمپین می‌پذیریم. کافیست که مقدار مورد نظر را به کیف‌پول 1BdL9ZkQunCnQjqjpZSyCxETbWaSw23FXT بفرستید یا ابتدا کد مقابل را اسکن و سپس مبلغ مورد نظر را بفرستید. لازم به ذکر است که می‌توانید بیتکوین خود را از صرافی فرهاداکسچنچ تهیه کنید. در صورت داشتن سوال و یا اعلام حمایت مالی (بزودی لیست حامیان منتشر می‌شود :)) به donate@letwomen.in ایمیل بزنید (برای اعلام حمایت، لازم به اثبات پرداخت نیز هست!)
                                </p>
                                <p>
                                    از طرفی دیگر برای نشان دادن حسن نیت خود، این پروژه را به صورت متن-باز در گیت‌هاب آپلود کرده و از علاقه‌مندان نیز دعوت به همکاری در تکمیل و بهبود این پروژه می‌کنیم!
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</main>
<!-- Your site ends -->

<script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
<script src="static/js/materialize.min.js"></script>
<script>
    $(document).ready(function() {
        $('select').material_select();
    });
</script>

</body>

</html>

