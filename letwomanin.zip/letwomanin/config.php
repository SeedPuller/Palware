<?php
define("DB_HOST","localhost");
define("DB_NAME","letwomenin");
define("DB_USER","root");
define("DB_PASS","1414alireza");

?>