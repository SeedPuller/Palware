<?php
include_once "DB.class.php";
$sql = new DbWorking();


// get salt for create hash


function getsalt($str)
{
    $saltStr = str_shuffle($str);
    $hash = sha1($saltStr . md5($str . $saltStr));
    return $hash;
}

// get string hash

function gethash($string,$salt){
    return crypt($string, '$5$rounds=5000$'.getsalt($salt).'$');
}

function secure($input) {

    $search = array(
        '@<script[^>]*?>.*?</script>@si',   // Strip out javascript
        '@<[\/\!]*?[^<>]*?>@si',            // Strip out HTML tags
        '@<style[^>]*?>.*?</style>@siU',    // Strip style tags properly
        '@<![\s\S]*?--[ \t\n\r]*>@'         // Strip multi-line comments
    );

    $input = preg_replace($search, '', $input);

    if (is_array($input)) {
        foreach($input as $var=>$val) {
            $output[$var] = sanitize($val);
        }
    }
    else {
        if (get_magic_quotes_gpc()) {
            $input = stripslashes($input);
        }

        $input  = htmlspecialchars($input);
    }
    return $input;
}


function recaptcha(){
    $secretkey = "6Lcp7iUUAAAAAPng7SF4ecLMsolMEJi7a3pnTAzP";

    if(isset($_POST["g-recaptcha-response"])){
        $verifyresp = json_decode(file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret={$secretkey}&response={$_POST['g-recaptcha-response']}"));
        if($verifyresp->success){
            return true;
        }else{
            return false;
        }
    }
}


function do_petetion(){
    global $sql;
    $mailinput = $_POST["mail"];
    $name = $_POST["username"];
    $gender = intval($_POST["gender"]);
    if(!recaptcha()){
        return "E1";
    }
    $ip = $_SERVER['REMOTE_ADDR'];
    if (isset($_COOKIE["L37WW08@N!N"])){
        return "A1";
    }
    $getlastip = $sql->query("SELECT `email_activated` FROM `petetion` WHERE ip=?;", array($ip));
    if($getlastip->rowCount() > 0){
        if($getlastip->fetch(2)["email_activated"] == 1){
            return "A1";
        }else{
            return "A0";
        }
    }
    $email = explode("@", $mailinput);
    $emailuser = $email[0];
    $emailhost = $email[1];
    if(strpos($email[1], "gmail")){
        $emailuser = str_replace(".", "", $emailuser);
        $email = "{$emailuser}@{$emailhost}";
    }else{
        $email = "{$emailuser}@{$emailhost}";
    }
    $emailfind = $sql->query("SELECT * FROM `petetion` WHERE `email`=?", array($email));
    if($emailfind->rowCount() > 0){
        $emailfetch = $emailfind->fetch(2);
        if($emailfetch["email_activated"] == 0){
            return "A0";
        }else{
            return "A1";
        }
    }else{
        $verify_token = gethash($email, str_shuffle(time()));
        $insert = $sql->query("INSERT INTO `petetion` (`id`, `name`, `email`, `gender`, `email_activated`, `activation_token`, `ip`) VALUES (NULL, ?, ?, ?, '0', ?, ?)", array($name, $email, $gender, $verify_token, $ip));
        if($insert){
            if(sendVerifyEmail($email, $verify_token)){
                return "S";
            }else{
                return "E0";
            }

        }else{
            return "E0";
        }
    }
}


function verifyEmail($email, $token){
    global $sql;
    $email = $email;
    $emailfind = $sql->query("SELECT * FROM  `petetion` WHERE `email`=?;", array($email));
    if($emailfind->rowCount() > 0){
        $datafetch =$emailfind->fetch(2);
        $fetchtoken = $datafetch["activation_token"];
        if($fetchtoken == $token){
            $sql->query("UPDATE `petetion` SET `email_activated` = '1', `activation_token`='NULL' WHERE `petetion`.`id`=? ;", array($datafetch['id']));
            setcookie("L37WW08@N!N", true, time()+60*60*24*365, "/");
            return "S";
        }else{
            return "E1";
        }
    }else{
        return "E1";
    }
}


function sendVerifyEmail($email, $token){
    $url = 'https://api.elasticemail.com/v2/email/send';
    try{
        $post = array('from' => 'info@letwomen.in',
            'fromName' => '#LetWomenIN',
            'apikey' => '9632d3a5-cada-4766-aef0-b958d54c2e96',
            'subject' => 'Email Verification',
            'to' => $email,
            'bodyHtml' => "<h1>تایید امضای شما</h1><br><div style='text-align: right'><b>سلام ! از اینکه دادخواست « حق 49 درصدی » رو امضا کردین از شما تشکر میکنیم ! <br> برای تایید صحت امضای خود روی لینک پایین کلیک کنید. توجه : در صورت تایید نکردن امضای خود ،‌امضای شما محاسبه نخواهد شد !<br>  Link :<a href=\"letwomen.in/?e={$email}&t={$token}\">Verify Link</a><br></div></b>",
            'bodyText' => '',
            'isTransactional' => false);

        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $post,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => false,
            CURLOPT_SSL_VERIFYPEER => false
        ));

        $result=json_decode(curl_exec ($ch));
        curl_close ($ch);

        if($result->success){
            return true;
        }
    }
    catch(Exception $ex){
        return false;
    }
}

?>



