(function($){
  $(function(){

    $('.button-collapse').sideNav({edge:"right"});

  }); // end of document ready
})(jQuery); // end of jQuery name space